"use client";

import React, { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { useMusic } from '@/context/music-context';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Volume1, Shuffle, Repeat } from 'lucide-react';
import { cn } from '@/lib/utils';

function formatTime(seconds: number) {
  if (isNaN(seconds)) return '0:00';
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function PlayerControls() {
  const { songs, currentTrackIndex, isPlaying, togglePlay, playNext, playPrev, audioRef } = useMusic();
  const currentTrack = currentTrackIndex !== null ? songs[currentTrackIndex] : null;

  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(1);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  const onTimeUpdate = useCallback(() => {
    if (audioRef.current) setProgress(audioRef.current.currentTime);
  }, [audioRef]);

  const onLoadedMetadata = useCallback(() => {
    if (audioRef.current) setDuration(audioRef.current.duration);
  }, [audioRef]);

  const onEnded = useCallback(() => {
    playNext();
  }, [playNext]);

  useEffect(() => {
    const audio = audioRef.current;
    if (audio) {
      audio.addEventListener('timeupdate', onTimeUpdate);
      audio.addEventListener('loadedmetadata', onLoadedMetadata);
      audio.addEventListener('ended', onEnded);
      return () => {
        audio.removeEventListener('timeupdate', onTimeUpdate);
        audio.removeEventListener('loadedmetadata', onLoadedMetadata);
        audio.removeEventListener('ended', onEnded);
      };
    }
  }, [audioRef, onTimeUpdate, onLoadedMetadata, onEnded]);
  
  const handleProgressChange = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0];
      setProgress(value[0]);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    if (audioRef.current) {
      const newVolume = value[0];
      audioRef.current.muted = false;
      setIsMuted(false);
      audioRef.current.volume = newVolume;
      setVolume(newVolume);
    }
  };
  
  const toggleMute = () => {
    if (audioRef.current) {
        audioRef.current.muted = !isMuted;
        setIsMuted(!isMuted);
    }
  }

  const VolumeIcon = isMuted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

  return (
    <footer className="h-24 bg-card/40 border-t backdrop-blur-sm grid grid-cols-3 items-center px-4 gap-4">
      <audio ref={audioRef} />
      <div className="flex items-center gap-3">
        {currentTrack && <>
            <Image src={currentTrack.coverArt!} alt={currentTrack.title} width={56} height={56} className="rounded-md aspect-square object-cover" data-ai-hint="music abstract"/>
            <div>
              <p className="font-semibold text-sm truncate">{currentTrack.title}</p>
              <p className="text-xs text-muted-foreground truncate">{currentTrack.artist}</p>
            </div>
        </>}
      </div>

      <div className="flex flex-col items-center justify-center gap-2">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <Shuffle className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={playPrev} disabled={!currentTrack} className="h-8 w-8">
            <SkipBack className="h-5 w-5" />
          </Button>
          <Button variant="default" size="icon" onClick={togglePlay} disabled={!currentTrack} className={cn("h-8 w-8 rounded-full bg-primary text-primary-foreground hover:bg-primary/90", isPlaying ? "bg-background text-foreground" : "")}>
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-current" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={playNext} disabled={!currentTrack} className="h-8 w-8">
            <SkipForward className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <Repeat className="h-4 w-4" />
          </Button>
        </div>
        <div className="w-full flex items-center gap-2">
          <span className="text-xs text-muted-foreground w-10 text-right">{formatTime(progress)}</span>
          <Slider value={[progress]} max={duration || 1} onValueChange={handleProgressChange} disabled={!currentTrack} className="[&>span:first-child]:h-1 [&_[role=slider]]:h-3 [&_[role=slider]]:w-3 [&_[role=slider]]:border-0 [&_[role=slider]]:opacity-0 hover:[&_[role=slider]]:opacity-100" />
          <span className="text-xs text-muted-foreground w-10">{formatTime(duration)}</span>
        </div>
      </div>

      <div className="flex items-center gap-2 justify-end">
        <Button variant="ghost" size="icon" onClick={toggleMute} disabled={!currentTrack} className="h-8 w-8 text-muted-foreground hover:text-foreground">
            <VolumeIcon className="h-5 w-5" />
        </Button>
        <Slider value={isMuted ? [0] : [volume]} max={1} step={0.01} className="w-24 [&>span:first-child]:h-1 [&_[role=slider]]:h-3 [&_[role=slider]]:w-3 [&_[role=slider]]:border-0 [&_[role=slider]]:opacity-0 hover:[&_[role=slider]]:opacity-100" onValueChange={handleVolumeChange} disabled={!currentTrack} />
      </div>
    </footer>
  );
}
