"use client";

import { useState, useEffect } from 'react';
import { LoadingScreen } from '@/components/loading-screen';
import AppLayout from '@/components/app-layout';
import { MusicProvider } from '@/context/music-context';

export default function AppShell() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <LoadingScreen loading={loading} />
      <div className={loading ? 'hidden' : 'block'}>
        <MusicProvider>
          <AppLayout />
        </MusicProvider>
      </div>
    </>
  );
}
