"use client";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useMusic, Playlist } from '@/context/music-context';

export function DeletePlaylistDialog({ playlist, onOpenChange }: { playlist: Playlist, onOpenChange: (open: boolean) => void }) {
  const { deletePlaylist } = useMusic();

  const handleDelete = () => {
    deletePlaylist(playlist.id);
    onOpenChange(false);
  };

  return (
    <AlertDialog open={true} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete playlist</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete the playlist "{playlist.name}"? This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
