"use client";

import { useMusic, Song } from '@/context/music-context';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from '@/components/ui/button';
import { MoreHorizontal, Music, Play, Clock, Trash2 } from 'lucide-react';
import Image from 'next/image';
import { useToast } from "@/hooks/use-toast"
import { HomeView } from './home-view';

function formatDuration(seconds: number) {
  if (isNaN(seconds) || seconds < 0) return "0:00";
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function MainView() {
  const { songs, playlists, currentView, playTrack, getPlaylistSongs, addSongToPlaylist, removeSongFromPlaylist, currentTrackIndex, isPlaying } = useMusic();
  const { toast } = useToast();

  if (currentView.type === 'home') {
    return <HomeView />;
  }

  let songsToShow: Song[] = [];
  let viewTitle = 'All Songs';
  if (currentView.type === 'library') {
    songsToShow = songs;
  } else {
    const playlist = playlists.find(p => p.id === currentView.id);
    if (playlist) {
      songsToShow = getPlaylistSongs(playlist.id);
      viewTitle = playlist.name;
    }
  }

  const handleAddToPlaylist = (playlistId: string, songId: string) => {
    addSongToPlaylist(playlistId, songId);
    toast({
        title: "Song added",
        description: `Added to playlist: ${playlists.find(p => p.id === playlistId)?.name}.`,
    });
  };

  const handleRemoveFromPlaylist = (playlistId: string, songId: string) => {
    removeSongFromPlaylist(playlistId, songId);
    toast({
      title: "Song removed",
      description: `Removed from playlist: ${playlists.find(p => p.id === playlistId)?.name}.`,
    });
  };

  if (songsToShow.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
        <Music className="h-16 w-16 mb-4"/>
        <h2 className="text-2xl font-bold mb-2 font-headline">{currentView.type === 'library' ? "Your library is empty" : "This playlist is empty"}</h2>
        <p>{currentView.type === 'library' ? "Upload some music to get started." : "Add songs to this playlist from your library."}</p>
      </div>
    );
  }
  
  const currentSong = currentTrackIndex !== null ? songs[currentTrackIndex] : null;

  return (
    <div className="pt-10">
      <div className="flex items-end gap-4 mb-6">
        <div className="w-48 h-48 bg-card rounded-md shadow-lg flex items-center justify-center">
            <Music className="w-24 h-24 text-muted-foreground" />
        </div>
        <div>
            <p className="text-sm">Playlist</p>
            <h1 className="text-8xl font-black">{viewTitle}</h1>
        </div>
      </div>
      <div className="p-4 bg-black/20">
        <Button size="icon" className="h-14 w-14 bg-primary rounded-full shadow-lg shadow-primary/30 hover:scale-105 transition-transform" onClick={() => playTrack(songs.findIndex(s => s.id === songsToShow[0].id))}>
          <Play className="h-7 w-7 fill-current text-primary-foreground" />
        </Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12 text-center">#</TableHead>
            <TableHead>Title</TableHead>
            <TableHead className="hidden lg:table-cell">Album</TableHead>
            <TableHead className="text-right w-24"><Clock className="h-4 w-4 inline-block" /></TableHead>
            <TableHead className="w-20"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {songsToShow.map((song, index) => {
            const originalIndex = songs.findIndex(s => s.id === song.id);
            const isActive = currentSong?.id === song.id;
            return (
              <TableRow key={song.id} className="group" data-state={isActive ? "selected" : "none"}>
                <TableCell className="text-center text-muted-foreground group-hover:hidden">{index + 1}</TableCell>
                <TableCell className="text-center text-muted-foreground hidden group-hover:table-cell">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => playTrack(originalIndex)}>
                      {isActive && isPlaying ? <Music className="h-4 w-4 animate-pulse text-primary"/> : <Play className="h-4 w-4"/>}
                    </Button>
                </TableCell>
                <TableCell>
                    <div className="flex items-center gap-3">
                        <Image src={song.coverArt!} alt={song.title} width={40} height={40} className="rounded aspect-square object-cover" data-ai-hint="music abstract" />
                        <div>
                            <div className={`font-medium ${isActive ? 'text-primary' : ''}`}>{song.title}</div>
                            <div className="text-sm text-muted-foreground">{song.artist}</div>
                        </div>
                    </div>
                </TableCell>
                <TableCell className="hidden lg:table-cell text-muted-foreground">{song.album}</TableCell>
                <TableCell className="text-right text-muted-foreground">{formatDuration(song.duration)}</TableCell>
                <TableCell className="text-right">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100">
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                            {currentView.type === 'playlist' && (
                              <>
                                <DropdownMenuItem onClick={() => handleRemoveFromPlaylist(currentView.id, song.id)} className="text-destructive">
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Remove from playlist
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                              </>
                            )}
                            <DropdownMenuLabel>Add to Playlist</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {playlists.filter(p => currentView.type === 'playlist' ? p.id !== currentView.id : true).map(p => (
                                <DropdownMenuItem key={p.id} onClick={() => handleAddToPlaylist(p.id, song.id)}>
                                    {p.name}
                                </DropdownMenuItem>
                            ))}
                             {playlists.length === 0 && <DropdownMenuItem disabled>No playlists yet</DropdownMenuItem>}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
