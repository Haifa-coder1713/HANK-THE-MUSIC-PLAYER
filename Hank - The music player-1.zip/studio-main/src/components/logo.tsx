import { Music } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Logo({ large = false }: { large?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2 font-bold tracking-tight text-foreground", large ? "text-5xl" : "text-2xl")}>
       <Music className={cn("text-primary", large ? "h-12 w-12" : "h-7 w-7")} />
      <span className="mt-1">Hank</span>
    </div>
  );
}
