"use client";

import { ChevronLeft, ChevronRight, Bell, Users, Search } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

export function TopBar() {
  return (
    <div className="flex items-center justify-between p-2 bg-card/40 sticky top-0 backdrop-blur-sm z-10">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="rounded-full bg-black/20" disabled>
          <ChevronLeft />
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full bg-black/20" disabled>
          <ChevronRight />
        </Button>
        <div className="relative ml-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="What do you want to play?" className="pl-9 bg-secondary rounded-full w-80" />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="rounded-full bg-black/20">
          <Bell className="h-5 w-5" />
        </Button>
         <Button variant="ghost" size="icon" className="rounded-full bg-black/20">
          <Users className="h-5 w-5" />
        </Button>
        <Avatar>
          <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
          <AvatarFallback>M</AvatarFallback>
        </Avatar>
      </div>
    </div>
  );
}
