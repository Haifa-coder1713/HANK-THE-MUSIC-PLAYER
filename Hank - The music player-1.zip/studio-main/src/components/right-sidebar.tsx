"use client"

import { useMusic } from "@/context/music-context"
import Image from "next/image";
import { Button } from "./ui/button";

export function RightSidebar() {
    const { songs, currentTrackIndex } = useMusic();
    const currentTrack = currentTrackIndex !== null ? songs[currentTrackIndex] : null;

    if (!currentTrack) {
        return (
            <aside className="w-80 bg-card p-4">
                <div className="h-full flex items-center justify-center text-muted-foreground text-center">
                    Select a song to see details.
                </div>
            </aside>
        )
    }

    return (
        <aside className="w-80 bg-card p-4 flex flex-col space-y-4">
            <h2 className="text-lg font-bold">Now Playing</h2>
            <div className="flex flex-col items-center text-center space-y-4">
                <Image src={currentTrack.coverArt!} alt={currentTrack.title} width={250} height={250} className="rounded-lg aspect-square object-cover shadow-lg" />
                <div>
                    <h3 className="text-xl font-bold">{currentTrack.title}</h3>
                    <p className="text-muted-foreground">{currentTrack.artist}</p>
                </div>
            </div>
            <div className="space-y-2">
                <h4 className="font-semibold">Credits</h4>
                <div className="bg-background/50 rounded-md p-3 space-y-3">
                {currentTrack.credits?.map((credit, index) => (
                    <div key={index} className="flex justify-between items-center">
                        <div>
                            <p className="font-semibold">{credit.name}</p>
                            <p className="text-xs text-muted-foreground">{credit.role}</p>
                        </div>
                        <Button variant="outline" size="sm" className="rounded-full text-xs h-7">Follow</Button>
                    </div>
                ))}
                </div>
            </div>
        </aside>
    )
}
