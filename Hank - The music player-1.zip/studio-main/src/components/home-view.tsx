"use client"

import { useMusic } from "@/context/music-context";
import { Card, CardContent } from "./ui/card";
import Image from "next/image";
import { Button } from "./ui/button";
import { Play } from "lucide-react";

export function HomeView() {
    const { songs, playTrack } = useMusic();

    const recommendedSongs = songs.slice(0, 5);
    const editorsPicks = songs.slice(5, 10);

    return (
        <div className="space-y-8">
            <div>
                <h2 className="text-2xl font-bold mb-4">Recommended for you</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {recommendedSongs.map(song => {
                        const originalIndex = songs.findIndex(s => s.id === song.id);
                        return (
                            <Card key={song.id} className="bg-card hover:bg-secondary transition-colors group">
                                <CardContent className="p-4 space-y-2 relative">
                                    <Image src={song.coverArt!} alt={song.title} width={200} height={200} className="rounded-md aspect-square object-cover w-full" data-ai-hint="music abstract" />
                                    <h3 className="font-semibold truncate">{song.title}</h3>
                                    <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
                                     <Button size="icon" className="absolute bottom-20 right-6 h-12 w-12 bg-primary rounded-full shadow-lg shadow-primary/30 opacity-0 group-hover:opacity-100 group-hover:bottom-24 transition-all" onClick={() => playTrack(originalIndex)}>
                                        <Play className="h-6 w-6 fill-current text-primary-foreground" />
                                    </Button>
                                </CardContent>
                            </Card>
                        )
                    })}
                </div>
            </div>
             <div>
                <h2 className="text-2xl font-bold mb-4">Editor's Pick</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {editorsPicks.map(song => {
                       const originalIndex = songs.findIndex(s => s.id === song.id);
                        return (
                            <Card key={song.id} className="bg-card hover:bg-secondary transition-colors group">
                                <CardContent className="p-4 space-y-2 relative">
                                    <Image src={song.coverArt!} alt={song.title} width={200} height={200} className="rounded-md aspect-square object-cover w-full" data-ai-hint="bollywood movie" />
                                    <h3 className="font-semibold truncate">{song.title}</h3>
                                    <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
                                     <Button size="icon" className="absolute bottom-20 right-6 h-12 w-12 bg-primary rounded-full shadow-lg shadow-primary/30 opacity-0 group-hover:opacity-100 group-hover:bottom-24 transition-all" onClick={() => playTrack(originalIndex)}>
                                        <Play className="h-6 w-6 fill-current text-primary-foreground" />
                                    </Button>
                                </CardContent>
                            </Card>
                        )
                    })}
                </div>
            </div>
        </div>
    )
}
