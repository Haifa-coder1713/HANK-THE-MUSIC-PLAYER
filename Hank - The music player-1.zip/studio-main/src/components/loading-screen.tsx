import { Logo } from '@/components/logo';

export function LoadingScreen({ loading }: { loading: boolean }) {
  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-background transition-opacity duration-500 ${
        loading ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
    >
      <div className="relative">
        <Logo large />
      </div>
    </div>
  );
}
