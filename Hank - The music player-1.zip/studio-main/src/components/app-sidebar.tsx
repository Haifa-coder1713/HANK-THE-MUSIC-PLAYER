"use client";

import React, { useRef, useState } from 'react';
import { Logo } from '@/components/logo';
import { Button } from '@/components/ui/button';
import { useMusic, Playlist } from '@/context/music-context';
import { Music, Upload, ListMusic, Plus, Home, MoreHorizontal } from 'lucide-react';
import { CreatePlaylistDialog } from '@/components/create-playlist-dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { EditPlaylistDialog } from '@/components/edit-playlist-dialog';
import { DeletePlaylistDialog } from '@/components/delete-playlist-dialog';

export function AppSidebar() {
  const { addSongs, playlists, setCurrentView, currentView } = useMusic();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCreatePlaylistOpen, setCreatePlaylistOpen] = useState(false);
  const [editingPlaylist, setEditingPlaylist] = useState<Playlist | null>(null);
  const [deletingPlaylist, setDeletingPlaylist] = useState<Playlist | null>(null);


  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      addSongs(event.target.files);
    }
  };

  return (
    <>
      <aside className="w-64 flex flex-col bg-card/40 p-2 space-y-2">
        <div className="bg-card rounded-md p-4 space-y-4">
          <Logo />
           <Button variant={currentView.type === 'home' ? 'secondary' : 'ghost'} className="w-full justify-start gap-4 text-base font-semibold" onClick={() => setCurrentView({ type: 'home' })}>
            <Home className="h-6 w-6" />
            Home
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-4 text-base font-semibold" onClick={handleUploadClick}>
            <Upload className="h-6 w-6" />
            Upload
          </Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="audio/*"
            multiple
            className="hidden"
          />
        </div>
        
        <div className="bg-card rounded-md p-2 flex-1 overflow-y-auto">
          <div className="p-2">
             <Button variant={currentView.type === 'library' ? 'secondary' : 'ghost'} className="justify-start gap-2 text-base font-semibold w-full" onClick={() => setCurrentView({ type: 'library' })}>
              <Music className="h-6 w-6" />
              All Songs
            </Button>
          </div>
          <div className="px-2 pb-2 flex items-center justify-between">
            <Button variant="secondary" size="sm" className="rounded-full h-8 px-3">Playlists</Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCreatePlaylistOpen(true)}>
              <Plus className="h-5 w-5" />
            </Button>
          </div>
          <nav className="flex flex-col space-y-1 p-2">
            {playlists.map(playlist => (
              <div key={playlist.id} className="group relative">
                <Button 
                  variant={currentView.type === 'playlist' && currentView.id === playlist.id ? 'secondary' : 'ghost'} 
                  className="w-full justify-start gap-2 pr-8"
                  onClick={() => setCurrentView({ type: 'playlist', id: playlist.id })}
                >
                  <ListMusic className="h-4 w-4" />
                  <span className="truncate">{playlist.name}</span>
                </Button>
                 <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6 absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100">
                            <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => setEditingPlaylist(playlist)}>Edit</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setDeletingPlaylist(playlist)} className="text-destructive">Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))}
             {playlists.length === 0 && (
                <div className="p-4 text-center text-sm text-muted-foreground">
                    <p className="font-bold">Create your first playlist</p>
                    <p className="text-xs">It's easy, we'll help you</p>
                    <Button variant="outline" className="mt-4 rounded-full" onClick={() => setCreatePlaylistOpen(true)}>Create playlist</Button>
                </div>
             )}
          </nav>
        </div>
      </aside>
      <CreatePlaylistDialog open={isCreatePlaylistOpen} onOpenChange={setCreatePlaylistOpen} />
      {editingPlaylist && <EditPlaylistDialog playlist={editingPlaylist} onOpenChange={(isOpen) => !isOpen && setEditingPlaylist(null)} />}
      {deletingPlaylist && <DeletePlaylistDialog playlist={deletingPlaylist} onOpenChange={(isOpen) => !isOpen && setDeletingPlaylist(null)} />}
    </>
  );
}
