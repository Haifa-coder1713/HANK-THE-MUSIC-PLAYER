"use client";

import { AppSidebar } from '@/components/app-sidebar';
import { MainView } from '@/components/main-view';
import { PlayerControls } from '@/components/player-controls';
import { RightSidebar } from '@/components/right-sidebar';
import { TopBar } from '@/components/top-bar';

export default function AppLayout() {
  return (
    <div className="h-screen grid grid-rows-[1fr_auto]">
        <div className="grid grid-cols-[auto_1fr_auto] overflow-hidden">
            <AppSidebar />
            <div className="flex flex-col overflow-hidden">
              <TopBar />
              <main className="overflow-y-auto p-4 md:p-6">
                  <MainView />
              </main>
            </div>
            <RightSidebar />
        </div>
        <PlayerControls />
    </div>
  );
}
