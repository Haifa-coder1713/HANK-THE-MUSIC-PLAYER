"use client";

import React, { createContext, useContext, useState, useRef, ReactNode, useCallback } from 'react';
import * as mm from 'music-metadata-browser';

export interface Song {
  id: string;
  url: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  coverArt?: string;
  credits?: { name: string; role: string }[];
}

export interface Playlist {
  id: string;
  name: string;
  songIds: string[];
}

type View = { type: 'library' } | { type: 'playlist', id: string } | { type: 'home' };

interface MusicContextType {
  songs: Song[];
  playlists: Playlist[];
  currentTrackIndex: number | null;
  isPlaying: boolean;
  currentView: View;
  audioRef: React.RefObject<HTMLAudioElement>;
  addSongs: (files: FileList) => void;
  createPlaylist: (name: string) => void;
  updatePlaylist: (playlistId: string, name: string) => void;
  deletePlaylist: (playlistId: string) => void;
  addSongToPlaylist: (playlistId: string, songId: string) => void;
  removeSongFromPlaylist: (playlistId: string, songId: string) => void;
  playTrack: (trackIndex: number) => void;
  togglePlay: () => void;
  playNext: () => void;
  playPrev: () => void;
  setCurrentView: (view: View) => void;
  getPlaylistSongs: (playlistId: string) => Song[];
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export const MusicProvider = ({ children }: { children: ReactNode }) => {
  const [songs, setSongs] = useState<Song[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentView, setCurrentView] = useState<View>({ type: 'home' });
  const audioRef = useRef<HTMLAudioElement>(null);

  const getPlaylistSongs = useCallback((playlistId: string) => {
    const playlist = playlists.find(p => p.id === playlistId);
    if (!playlist) return [];
    return playlist.songIds.map(songId => songs.find(s => s.id === songId)).filter((s): s is Song => s !== undefined);
  }, [playlists, songs]);

  const addSongs = useCallback(async (files: FileList) => {
    const newSongs: Song[] = [];
    for (const file of Array.from(files)) {
      if (file.type.startsWith('audio/')) {
        try {
          const metadata = await mm.parseBlob(file);
          const title = metadata.common.title || file.name.replace(/\.[^/.]+$/, "").replace(/_/g, ' ');
          const artist = metadata.common.artist || "Unknown Artist";
          const album = metadata.common.album || "Unknown Album";
          const duration = metadata.format.duration || 0;
          
          let coverArt = `https://picsum.photos/seed/${Math.random()}/200/200`;
          if (metadata.common.picture && metadata.common.picture.length > 0) {
            const picture = metadata.common.picture[0];
            const base64String = Buffer.from(picture.data).toString('base64');
            coverArt = `data:${picture.format};base64,${base64String}`;
          }

          const newSong: Song = {
            id: `${file.name}-${file.lastModified}-${file.size}`,
            url: URL.createObjectURL(file),
            title: title,
            artist: artist,
            album: album,
            duration: duration,
            coverArt: coverArt,
            credits: [{ name: artist, role: "Main Artist" }]
          };
          newSongs.push(newSong);
        } catch (error) {
          console.error("Error reading metadata for file", file.name, error);
        }
      }
    }
    setSongs(prev => [...prev, ...newSongs]);
    if (newSongs.length > 0) {
        setCurrentView({ type: 'library' });
    }
  }, []);

  const createPlaylist = useCallback((name: string) => {
    const newPlaylist: Playlist = {
      id: `playlist-${Date.now()}`,
      name,
      songIds: [],
    };
    setPlaylists(prev => [...prev, newPlaylist]);
  }, []);

  const updatePlaylist = useCallback((playlistId: string, name: string) => {
    setPlaylists(prev => prev.map(p => p.id === playlistId ? { ...p, name } : p));
  }, []);

  const deletePlaylist = useCallback((playlistId: string) => {
    setPlaylists(prev => prev.filter(p => p.id !== playlistId));
    setCurrentView({ type: 'library' });
  }, []);
  
  const addSongToPlaylist = useCallback((playlistId: string, songId: string) => {
    setPlaylists(playlists => playlists.map(p =>
      p.id === playlistId && !p.songIds.includes(songId) ? { ...p, songIds: [...p.songIds, songId] } : p
    ));
  }, []);

  const removeSongFromPlaylist = useCallback((playlistId: string, songId: string) => {
    setPlaylists(playlists => playlists.map(p => 
      p.id === playlistId ? { ...p, songIds: p.songIds.filter(id => id !== songId) } : p
    ));
  }, []);

  const playTrack = useCallback((trackIndex: number) => {
    if (trackIndex >= 0 && trackIndex < songs.length) {
      setCurrentTrackIndex(trackIndex);
      setIsPlaying(true);
      if (audioRef.current) {
        audioRef.current.src = songs[trackIndex].url;
        audioRef.current.play();
      }
    }
  }, [songs]);

  const togglePlay = useCallback(() => {
    if (audioRef.current && currentTrackIndex !== null) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    } else if (currentTrackIndex === null && songs.length > 0) {
        playTrack(0);
    }
  }, [isPlaying, currentTrackIndex, songs, playTrack]);

  const playNext = useCallback(() => {
    if (songs.length === 0) return;
    const currentListSongs = (currentView.type === 'playlist' ? getPlaylistSongs(currentView.id) : null) ?? songs;
    if (currentListSongs.length === 0) return;

    const currentSongId = currentTrackIndex !== null ? songs[currentTrackIndex].id : null;
    const currentIndexInList = currentListSongs.findIndex(s => s.id === currentSongId);

    const nextIndexInList = (currentIndexInList + 1) % currentListSongs.length;
    const nextSongId = currentListSongs[nextIndexInList].id;
    const globalNextIndex = songs.findIndex(s => s.id === nextSongId);
    
    playTrack(globalNextIndex);
  }, [currentTrackIndex, songs, currentView, getPlaylistSongs, playTrack]);

  const playPrev = useCallback(() => {
    if (songs.length === 0) return;
    const currentListSongs = (currentView.type === 'playlist' ? getPlaylistSongs(currentView.id) : null) ?? songs;
    if (currentListSongs.length === 0) return;

    const currentSongId = currentTrackIndex !== null ? songs[currentTrackIndex].id : null;
    const currentIndexInList = currentListSongs.findIndex(s => s.id === currentSongId);

    const prevIndexInList = (currentIndexInList - 1 + currentListSongs.length) % currentListSongs.length;
    const prevSongId = currentListSongs[prevIndexInList].id;
    const globalPrevIndex = songs.findIndex(s => s.id === prevSongId);

    playTrack(globalPrevIndex);
  }, [currentTrackIndex, songs, currentView, getPlaylistSongs, playTrack]);

  const value = {
    songs,
    playlists,
    currentTrackIndex,
    isPlaying,
    currentView,
    audioRef,
    addSongs,
    createPlaylist,
    updatePlaylist,
    deletePlaylist,
    addSongToPlaylist,
    removeSongFromPlaylist,
    playTrack,
    togglePlay,
    playNext,
    playPrev,
    setCurrentView,
    getPlaylistSongs,
  };

  return <MusicContext.Provider value={value}>{children}</MusicContext.Provider>;
};

export const useMusic = () => {
  const context = useContext(MusicContext);
  if (context === undefined) {
    throw new Error('useMusic must be used within a MusicProvider');
  }
  return context;
};
