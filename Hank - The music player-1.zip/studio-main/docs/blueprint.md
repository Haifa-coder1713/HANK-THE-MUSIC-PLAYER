# **App Name**: Hunk

## Core Features:

- Local Music Upload: Allow users to upload music files (e.g., MP3) from their local device storage.
- Library Management: Organize uploaded music into playlists and a central library.
- Playback Controls: Implement standard music player controls (play, pause, skip, volume, etc.).
- Metadata Display: Display song metadata (title, artist, album) fetched from the audio files.
- Playlist Creation: Allow users to create, edit, and delete custom playlists.
- Loading Animation: Create a loading screen featuring a thunder and lightning effect while the app initializes.

## Style Guidelines:

- Primary color: Deep indigo (#4B0082), reminiscent of a powerful storm.
- Background color: Very dark gray (#222222), nearly black, for a dramatic feel.
- Accent color: Electric purple (#8F00FF) to mimic the vibrancy of lightning, used for interactive elements.
- Body and headline font: 'Space Grotesk' sans-serif font for a techy and powerful appearance
- Use crisp, modern icons for playback controls and library management, with subtle glow effects.
- Dark theme layout with a focus on visual clarity and easy navigation.
- Implement subtle animations for track transitions and interactive elements to enhance user engagement.